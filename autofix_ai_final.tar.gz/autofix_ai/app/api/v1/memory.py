"""
app/api/v1/memory.py
Second Brain memory management.
Eviction: SRE | ADMIN only. Audit log on every eviction.
"""
from __future__ import annotations

import uuid
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.dependencies.auth import CurrentUser, get_current_user
from app.models.memory_entry import MemoryEntry
from app.models.user import UserRole
from app.repositories.audit_repository import AuditRepository
from app.repositories.memory_repository import MemoryRepository
from app.services.cache_service import get_repair_cache

router = APIRouter(prefix="/memory", tags=["memory"])


class MemoryEntryResponse(BaseModel):
    id: int
    structural_hash: str
    error_type: str
    fix_source: str
    validation_level: str
    success_count: int
    failure_count: int
    confidence: float

    model_config = {"from_attributes": True}


@router.get("", response_model=dict)
async def list_memory(
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: AsyncSession = Depends(get_db),
    min_confidence: float = 0.0,
) -> dict:
    """
    Return all memory entries above min_confidence.
    Single DB query via get_all() — no hardcoded error-type scanning.
    Memory is shared org-level knowledge; all authenticated users can read.
    """
    repo = MemoryRepository(db)
    entries = await repo.get_all(min_confidence=min_confidence)
    return {
        "items": [MemoryEntryResponse.model_validate(e) for e in entries],
        "total": len(entries),
    }


@router.get("/stats")
async def memory_stats(
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: AsyncSession = Depends(get_db),
) -> dict:
    repo = MemoryRepository(db)
    db_stats = await repo.get_stats()
    cache = get_repair_cache()
    return {
        **db_stats,
        "cache_hit_rate": cache.hit_rate,
        "cache_size": cache.stats()["size"],
    }


@router.delete("/{entry_id}", status_code=204)
async def evict_memory(
    entry_id: int,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: AsyncSession = Depends(get_db),
) -> None:
    """
    Evict a memory entry from the Second Brain and flush it from L1 cache.
    SRE | ADMIN only. Immutable audit log written before deletion.
    """
    if current_user.role not in (UserRole.SRE.value, UserRole.ADMIN.value):
        raise HTTPException(403, "SRE or ADMIN required")

    async with db.begin():
        # Single direct lookup by primary key — no dead get_by_hash("") call
        result = await db.execute(
            select(MemoryEntry).where(MemoryEntry.id == entry_id)
        )
        entry = result.scalar_one_or_none()
        if not entry:
            raise HTTPException(404, "Memory entry not found")

        # Evict from L1 cache before DB delete
        get_repair_cache().evict(entry.structural_hash)

        repo = MemoryRepository(db)
        await repo.evict(entry_id)

        # Audit log — inside same transaction as the delete
        await AuditRepository(db).write(
            org_id=current_user.org_id,
            user_id=current_user.id,
            action="MEMORY_EVICTED",
            resource_type="memory_entry",
            resource_id=uuid.uuid4(),
            metadata={"entry_id": entry_id, "error_type": entry.error_type},
        )
