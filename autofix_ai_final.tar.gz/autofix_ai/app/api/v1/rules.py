"""
app/api/v1/rules.py
Rule Engine CRUD.
POST/PATCH/DELETE: SRE | ADMIN only.
GET: all authenticated users.
Audit log written on every mutation.
LLM cannot create rules — human-only invariant enforced here.
"""
from __future__ import annotations

import uuid
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.dependencies.auth import CurrentUser, get_current_user
from app.models.user import UserRole
from app.repositories.audit_repository import AuditRepository
from app.repositories.rule_repository import RuleRepository

router = APIRouter(prefix="/rules", tags=["rules"])


class RuleCreate(BaseModel):
    name: str = Field(..., min_length=3, max_length=256)
    description: str | None = None
    condition_yaml: str = Field(..., min_length=5)
    action_type: str = Field(..., pattern=r"^(ADD_PACKAGE|CORRECT_TYPO|ADD_ENV_VAR|FIX_IMPORT|FIX_SYNTAX|ADD_NONE_GUARD)$")
    action_params: dict | None = None
    confidence: float = Field(default=0.80, ge=0.0, le=1.0)


class RulePatch(BaseModel):
    is_active: bool | None = None
    confidence: float | None = Field(default=None, ge=0.0, le=1.0)


class RuleResponse(BaseModel):
    id: uuid.UUID
    name: str
    description: str | None
    action_type: str
    confidence: float
    hit_count: int
    success_count: int
    failure_count: int
    is_active: bool
    source: str

    model_config = {"from_attributes": True}


@router.get("", response_model=dict)
async def list_rules(
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: AsyncSession = Depends(get_db),
) -> dict:
    repo = RuleRepository(db)
    rules = await repo.get_active_rules(org_id=current_user.org_id)
    return {"rules": [RuleResponse.model_validate(r) for r in rules], "total": len(rules)}


@router.post("", response_model=RuleResponse, status_code=201)
async def create_rule(
    body: RuleCreate,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: AsyncSession = Depends(get_db),
) -> RuleResponse:
    """SRE | ADMIN only. Audit log mandatory."""
    if current_user.role not in (UserRole.SRE.value, UserRole.ADMIN.value):
        raise HTTPException(403, "SRE or ADMIN required")

    async with db.begin():
        repo = RuleRepository(db)
        audit = AuditRepository(db)

        rule = await repo.create(
            org_id=current_user.org_id,
            name=body.name,
            description=body.description,
            condition_yaml=body.condition_yaml,
            action_type=body.action_type,
            action_params=body.action_params,
            confidence=body.confidence,
            created_by=current_user.id,
        )
        await audit.write(
            org_id=current_user.org_id,
            user_id=current_user.id,
            action="RULE_CREATED",
            resource_type="rule",
            resource_id=rule.id,
            metadata={"name": rule.name, "action_type": rule.action_type},
        )

    return RuleResponse.model_validate(rule)


@router.patch("/{rule_id}", response_model=RuleResponse)
async def update_rule(
    rule_id: uuid.UUID,
    body: RulePatch,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: AsyncSession = Depends(get_db),
) -> RuleResponse:
    if current_user.role not in (UserRole.SRE.value, UserRole.ADMIN.value):
        raise HTTPException(403, "SRE or ADMIN required")

    async with db.begin():
        repo = RuleRepository(db)
        rule = await repo.get_by_id(rule_id)
        if not rule:
            raise HTTPException(404, "Rule not found")

        if body.is_active is not None:
            rule.is_active = body.is_active
        if body.confidence is not None:
            rule.confidence = body.confidence

        audit = AuditRepository(db)
        await audit.write(
            org_id=current_user.org_id,
            user_id=current_user.id,
            action="RULE_UPDATED",
            resource_type="rule",
            resource_id=rule_id,
            metadata=body.model_dump(exclude_none=True),
        )

    return RuleResponse.model_validate(rule)


@router.delete("/{rule_id}", status_code=204)
async def delete_rule(
    rule_id: uuid.UUID,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: AsyncSession = Depends(get_db),
) -> None:
    """Soft delete — ADMIN only."""
    if current_user.role != UserRole.ADMIN.value:
        raise HTTPException(403, "ADMIN required")

    async with db.begin():
        repo = RuleRepository(db)
        rule = await repo.get_by_id(rule_id)
        if not rule:
            raise HTTPException(404, "Rule not found")

        await repo.soft_delete(rule_id)
        audit = AuditRepository(db)
        await audit.write(
            org_id=current_user.org_id,
            user_id=current_user.id,
            action="RULE_DELETED",
            resource_type="rule",
            resource_id=rule_id,
        )
