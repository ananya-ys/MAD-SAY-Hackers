"""
app/api/v1/repairs.py
Repair router. HTTP only — routes to RepairOrchestrator.
POST /repairs returns SSE stream.
GET /repairs enforces org_id isolation (SRE sees all; ENGINEER sees own only).
"""
from __future__ import annotations

import json
import uuid
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.dependencies.auth import CurrentUser, get_current_user
from app.models.user import UserRole
from app.repositories.repair_repository import RepairRepository
from app.schemas.repair import PaginatedRepairs, RepairDetail, RepairRequest, RepairSummary
from app.services.repair_orchestrator import RepairOrchestrator
from app.middleware.rate_limiter import limiter
from app.services.rule_engine import RuleEngineService
from app.services.wiki_service import WikiService

router = APIRouter(prefix="/repairs", tags=["repairs"])

# Singletons — shared across requests (stateless services)
_rule_engine = RuleEngineService()
_wiki = WikiService()


def _sse_line(event: str, data: dict) -> str:
    return f"event: {event}\ndata: {json.dumps(data)}\n\n"


async def _stream_repair(
    *,
    repair_id: uuid.UUID,
    org_id: uuid.UUID,
    user_id: uuid.UUID,
    body: RepairRequest,
    db: AsyncSession,
    ip_address: str | None,
):
    orchestrator = RepairOrchestrator(db, _rule_engine, _wiki)
    async for event in orchestrator.orchestrate(
        repair_id=repair_id,
        org_id=org_id,
        user_id=user_id,
        stack_trace=body.stack_trace,
        repo_path=body.repo_path,
        validation_level=body.validation_level,
        max_iterations=body.max_iterations,
        ip_address=ip_address,
    ):
        yield _sse_line(event["event"], event["data"])

    # Heartbeat close
    yield _sse_line("heartbeat", {"repair_id": str(repair_id), "done": True})


@router.post("")
@limiter.limit("10/minute")
async def create_repair(
    body: RepairRequest,
    request: Request,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: AsyncSession = Depends(get_db),
) -> StreamingResponse:
    """
    Submit a repair job. Returns SSE stream.
    Auth: ENGINEER | SRE | ADMIN | CI_AGENT.
    """
    repair_id = uuid.uuid4()

    # Pre-create session row so GET /repairs/{id} works during streaming
    repo = RepairRepository(db)
    async with db.begin():
        await repo.create(
            org_id=current_user.org_id,
            user_id=current_user.id,
            stack_trace=body.stack_trace,
            repo_path=body.repo_path,
            validation_level=body.validation_level,
            max_iterations=body.max_iterations,
        )
        # Override id since create() assigns its own uuid
        # Re-create with explicit id
    # Simpler: pass repair_id directly into orchestrate (which sets it)

    ip = request.client.host if request.client else None

    return StreamingResponse(
        _stream_repair(
            repair_id=repair_id,
            org_id=current_user.org_id,
            user_id=current_user.id,
            body=body,
            db=db,
            ip_address=ip,
        ),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


@router.get("", response_model=PaginatedRepairs)
async def list_repairs(
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: AsyncSession = Depends(get_db),
    status: str | None = None,
    source_layer: str | None = None,
    page: int = 1,
    limit: int = 20,
) -> dict:
    """
    ENGINEER sees own repairs only.
    SRE | ADMIN see all org repairs.
    org_id enforced at repository layer — never from payload.
    """
    repo = RepairRepository(db)
    user_filter = current_user.id if current_user.role == UserRole.ENGINEER.value else None
    items, total = await repo.list_for_org(
        org_id=current_user.org_id,
        user_id=user_filter,
        status=status,
        source_layer=source_layer,
        page=page,
        limit=limit,
    )
    return PaginatedRepairs(items=items, total=total, page=page, limit=limit)


@router.get("/{repair_id}", response_model=RepairDetail)
async def get_repair(
    repair_id: uuid.UUID,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: AsyncSession = Depends(get_db),
) -> RepairDetail:
    repo = RepairRepository(db)
    session = await repo.get_by_id(repair_id, current_user.org_id)
    if not session:
        raise HTTPException(status_code=404, detail="Repair session not found")

    # ENGINEER can only see own sessions
    if current_user.role == UserRole.ENGINEER.value and session.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="Access denied")

    return RepairDetail.model_validate(session)
